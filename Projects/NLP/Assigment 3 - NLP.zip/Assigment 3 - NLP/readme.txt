libraries used:
from collections import defaultdict
from nltk.corpus import wordnet as wn
import io
import nltk
import re
from collections import Counter
import itertools
---------------------
python version: 2.7
-----------------------
**Both the original as well as the enhanced version is part of the same .ipynb file. The original has been commented. Instrictions have been provided in the file itself. Please comment.uncomment the modules as required.**
-----------------------